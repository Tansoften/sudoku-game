package implement;
import javax.swing.*;

public class GUIComponet {
static   int EvenOrOddCol = 1;

 //They're used to store sudoku dimensions
 static int y = 0, x = 0;//They're set to zero on start when sudoku has no dimensions

 static int EvenOrOddRow = 1;
  static  JTextField bt[][] = new JTextField[y][x];
  static int verticeX,verticeY;

}
